<?php 
 
class Table extends CI_Controller{
 
	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "masuk"){
			redirect(base_url("masuk"));
		}
	}
 
	function index(){
		$this->load->view('admin/tables.php');
	}
}